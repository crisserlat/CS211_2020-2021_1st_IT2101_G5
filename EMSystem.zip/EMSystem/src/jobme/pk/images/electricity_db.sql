-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2020 at 03:39 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `electricity_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_history`
--

CREATE TABLE `account_history` (
  `id` int(11) NOT NULL,
  `date_history` varchar(100) NOT NULL,
  `account_num` varchar(100) NOT NULL,
  `watts` varchar(100) NOT NULL,
  `hour` varchar(100) NOT NULL,
  `total_kwh` varchar(100) NOT NULL,
  `total_cost` float NOT NULL,
  `payment_enter` float NOT NULL,
  `payment_change` float NOT NULL,
  `balance` float NOT NULL,
  `Username` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account_history`
--

INSERT INTO `account_history` (`id`, `date_history`, `account_num`, `watts`, `hour`, `total_kwh`, `total_cost`, `payment_enter`, `payment_change`, `balance`, `Username`) VALUES
(1, '12/03/2020', '201512145', '124.0', '24.0', '2.976', 62.496, 61, 0, 0, 'RICHO'),
(2, '11/03/2020', '201512145', '2486.0', '24.0', '59.664', 1252.94, 1000, 0, 252.944, 'RICHO');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `UserType` varchar(100) NOT NULL,
  `Nickname` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `UID` varchar(100) NOT NULL,
  `account_num` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `Username`, `Password`, `UserType`, `Nickname`, `Email`, `UID`, `account_num`) VALUES
(9, 'admin', 'admin', 'Admin', 'asd', '@gm', 'null', '12341245'),
(10, 'Cris', 'password2', 'Client', 'Cris Lats', 'cris@gmail.com', 'null', '201512145'),
(13, 'RICHO', 'pass', 'Client', 'Jeric magpantay', 'jemagpantay30@gmail.com', 'null', '201512145');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_history`
--
ALTER TABLE `account_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_history`
--
ALTER TABLE `account_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
