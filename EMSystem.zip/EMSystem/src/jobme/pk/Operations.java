/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jobme.pk;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Crisser Lat
 */
public class Operations {
    public static boolean isLogin(String username, String password, String usertype, JFrame frame){
        try{
            Connection myConn = MySQLConnection.getConnection();
            String mySqlQuery = 
                    "SELECT * FROM login WHERE Username = '"+
                    username+
                    "' AND Password = '"+
                    password+
                    "' AND Usertype = '"+
                    usertype+
                    "'";
            PreparedStatement preparedStatement = myConn.prepareStatement(mySqlQuery);
            ResultSet resultSet = preparedStatement.executeQuery();
            
            String mySqlQuery2 = 
                    "SELECT sum(balance) FROM account_history WHERE Username = '"+
                    username+
                    "'";
              PreparedStatement preparedStatement2 = myConn.prepareStatement(mySqlQuery2);
              ResultSet resultSet2 = preparedStatement2.executeQuery();
            
            while(resultSet.next() & resultSet2.next()){
                LoginSession.UID = resultSet.getString("UID");
                LoginSession.Usertype = resultSet.getString("Usertype");
                LoginSession.Username = resultSet.getString("Username");
                LoginSession.account_num = resultSet.getString("account_num");
                LoginSession.Password = resultSet.getString("Password");
                 LoginSession.ID = resultSet.getString("id");
                  LoginSession.Nickname = resultSet.getString("Nickname");
                
                
                LoginSession.balance = resultSet2.getString("sum(balance)");
                return true;
            }
            
        }catch (Exception exception){
            JOptionPane.showMessageDialog(frame, "Database error: " + exception.getMessage());
        }
        
        return false;
    }
}
