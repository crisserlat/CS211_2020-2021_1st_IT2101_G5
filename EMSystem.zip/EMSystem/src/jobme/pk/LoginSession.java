/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jobme.pk;

/**
 *
 * @author Crisser Lat
 */
public class LoginSession {
    public static String UID; // Global User ID
    public static String Usertype; // Global Usertype
    public static String Username; // Global Nickname
    public static String account_num;
    public static String Password;
    public static String ID;
    public static String balance;
    public static String Nickname;
    public static boolean isLoggedIn = false; // Check is User is logged in.
}
